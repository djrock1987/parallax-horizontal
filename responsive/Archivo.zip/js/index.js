! function e(t, i, r) {
    function n(o, a) {
        if (!i[o]) {
            if (!t[o]) {
                var l = "function" == typeof require && require;
                if (!a && l) return l(o, !0);
                if (s) return s(o, !0);
                var d = new Error("Cannot find module '" + o + "'");
                throw d.code = "MODULE_NOT_FOUND", d
            }
            var c = i[o] = {
                exports: {}
            };
            t[o][0].call(c.exports, function(e) {
                var i = t[o][1][e];
                return n(i ? i : e)
            }, c, c.exports, e, t, i, r)
        }
        return i[o].exports
    }
    for (var s = "function" == typeof require && require, o = 0; o < r.length; o++) n(r[o]);
    return n
}({
    1: [function(e) {
        e("../libs/jquery.mousewheel.js"), e("../libs/jquery.custom.js"), e("../util/customEventEngine.js"), e("../layout/parallax.js"), e("../layout/resizeables.js"), e("../ui/preloader.js"), e("../pages/index.js"), e("../pages/indexNav.js")
    }, {
        "../layout/parallax.js": 2,
        "../layout/resizeables.js": 3,
        "../libs/jquery.custom.js": 4,
        "../libs/jquery.mousewheel.js": 5,
        "../pages/index.js": 6,
        "../pages/indexNav.js": 7,
        "../ui/preloader.js": 8,
        "../util/customEventEngine.js": 9
    }],
    2: [function() {
        window.parallax = function(e) {
            function t(e, t) {
                var i = e.hasClass(b);
                this.$src = e, this.prnt = t, this.spd = +e.attr("data-speed"), i && e.css("min-height", "100%");
                var r, n, s, o, a, l, d = 1 - this.spd,
                    c = this.spd - 1,
                    u = e.hasClass(w),
                    h = 0;
                return L == S.CSS3_EASED && v(T, this.$src), this.applyWindowSize = function() {
                    if (i) {
                        hotdot.applyHorizontalShift("", e), e.css({
                            width: ""
                        });
                        var d = navigator.userAgent.indexOf("Opera") > -1;
                        d || e.css({
                            position: ""
                        })
                    } else e.attr("style", "");
                    if (r = z / 2, n = this.prnt.width / 2, i) {
                        this.width = e.width();
                        var c = this.spd * (this.prnt.prnt.width - z) + z;
                        this.width < c && (this.width = c, e.width(this.width))
                    } else e.css("position", "absolute"), this.width = e.width(), e.css("position", "");
                    o = this.width / 2, l = t.width - this.width, a = this.spd <= 1 && this.width < this.prnt.width, this.overflowsParent = u || i || !a, this.$src.css("left", "");
                    var h = e.css("left");
                    e.css({
                        display: "inline-block",
                        overflow: "visible",
                        position: "absolute"
                    }), this.left = "auto" == h ? n - o : parseInt(h, 10), T !== E.LEFT && this.$src.css("left", "0px"), s = 0 == this.spd ? r - o : this.spd > 0 && this.spd < 1 ? (r - o) * (1 - this.spd) + this.left * this.spd : this.left
                }, this.parallaxLeft = function(e) {
                    return this.currentLeft = 0 == this.spd ? s + e : this.spd > 0 && this.spd < 1 ? s + e * d : s - e * c, this.currentLeft
                }, this.adjust = function(e) {
                    var t = this.parallaxLeft(e);
                    if (!this.overflowsParent) {
                        var i = h,
                            r = l;
                        i > t ? t = i : t > r && (t = r)
                    }
                    L == S.CSS3_EASED || L == S.NONE ? hotdot.applyHorizontalShift(t, this.$src, T) : L == S.JQ_EASED && g(this.$src, t)
                }, this
            }

            function i(i, r, n) {
                this.masterSlide = r, this.layers = [], this.$src = i, this.initialLeft = 0, this.left = 0, this.width = 0, this.$axis = {}, this.prnt = n;
                var s, o = this.$src.children();
                this.childrenVisible = !0, this.adjust = function() {
                    this.left = this.initialLeft - this.prnt.$src.scroll;
                    var t = this.left + this.width,
                        i = this.left < 0 && 0 > t,
                        r = this.left > s && t > s;
                    if (!i && !r || e.noSlideHideOptimization) {
                        this.childrenVisible || (o.show(), this.childrenVisible = !0);
                        for (var n = -this.left, a = 0, l = this.layers[0], d = this.layers.length; d > a; a++, l = this.layers[a]) l.adjust(n)
                    } else this.childrenVisible && (o.hide(), this.childrenVisible = !1)
                };
                var a = this;
                return this.applyWindowSize = function() {
                    s = z, this.$src.css("display", ""), r ? (this.width = this.prnt.width, this.initialLeft = 0) : (this.width = z, this.initialLeft = this.prnt.width, this.$src.css("width", this.width))
                }, this.applyWindowSize(), this.applyWindowSizeToChildren = function() {
                    o.show();
                    for (var e = 0, t = a.layers.length; t > e; e++) a.layers[e].applyWindowSize()
                }, this.initChildren = function() {
                    var e;
                    e = r ? this.$src.children("[data-speed]") : $("*[data-speed]", this.$src), o.show(), e.each(function() {
                        var e = $(this);
                        if ("1" == e.attr("data-speed")) e.css({
                            position: "absolute"
                        }), a.$axis = e;
                        else {
                            var i = new t(e, a);
                            a.layers.push(i)
                        }
                    })
                }, this.initChildren(), this
            }

            function r() {
                M.$src = $("#" + m), M.$src.scroll = 0, y ? $("html").css("overflow", "hidden") : $("html").css({
                    "overflow-x": "scroll",
                    "overflow-y": "hidden"
                }), M.$src.children("div").css({
                    height: "100%",
                    position: "relative",
                    "float": "left",
                    overflow: "hidden"
                }), M.$src.css({
                    width: "100%",
                    height: "100%",
                    "overflow-x": "visible",
                    position: "fixed"
                }), C === S.CSS3_EASED && v(I, M.$src), n(), s(), o(), h(), $("." + b).css("z-index", "auto"), this.onInit()
            }

            function n() {
                M.array = [], M.$src.find("> div").each(function() {
                    var e = $(this);
                    if (!e.attr("data-speed")) {
                        var t = new i(e, !1, M);
                        M.array.push(t)
                    }
                }), D.slidesCount = M.array.length;
                var e = new i(M.$src, !0, M);
                M.array.push(e)
            }

            function s() {
                z = $(window).innerWidth(), M.singleSlideWidth = z, k.minimalStep = z / 1e3 / 15, M.width = 0;
                for (var e = 0, t = M.array.length; t > e; e++) {
                    var i = M.array[e];
                    i.applyWindowSize(), i.masterSlide || (M.width += i.width)
                }
                M.$src.width(M.width), k.maxLimit = M.width - z, f()
            }

            function o() {
                for (var e = 0, t = M.array[e]; e < M.array.length; e++, t = M.array[e]) t.applyWindowSizeToChildren();
                void 0 !== customEventEngine && customEventEngine.call(D, "engineRebuild", M.$src.scroll)
            }

            function a() {
                P = (k.cur - M.$src.scroll) / 15, Math.abs(P) > k.minimalStep ? (M.$src.scroll += P, u()) : k.doingNextMove && (k.doingNextMove = !1, void 0 !== customEventEngine && customEventEngine.call(D, "finishedMove", M.$src.scroll), M.$src.removeClass("disable-hover"))
            }

            function l() {
                M.$src.scroll = k.cur, u(), W = !1
            }

            function d() {
                if (F = k.cur / M.singleSlideWidth, "onBorder" == N) {
                    for (; R - .5 >= F;) para.currentSlideI--, R = para.currentSlideI;
                    for (; F >= R + .5;) para.currentSlideI++, R = para.currentSlideI
                } else {
                    for (; R - 1 >= F;) para.currentSlideI--, R = para.currentSlideI;
                    for (; F >= R + 1;) para.currentSlideI++, R = para.currentSlideI
                }
            }

            function c() {
                k.cur = k.get(), k.delta = Math.abs(M.$src.scroll - k.cur), k.doingNextMove = !0, void 0 !== customEventEngine && customEventEngine.call(D, "startedMove", M.$src.scroll), W || M.$src.addClass("disable-hover"), W ? l() : x == S.EASED ? j || (j = setInterval(a, 17)) : x == S.SUPER_EASED ? k.delta > 70 ? (k.firstStep = !0, M.$src.stop(!0, !0).animate({
                    scroll: k.cur
                }, {
                    step: function(e, t) {
                        return k.firstStep ? (t.start = M.$src.scroll, void(k.firstStep = !1)) : (u(), void(M.$src.scroll = e))
                    },
                    duration: A,
                    easing: _
                })) : (M.$src.stop(!0, !0), M.$src.scroll = k.cur, u()) : x == S.JQ_EASED ? M.$src.stop().animate({
                    scroll: k.cur
                }, {
                    step: function(e) {
                        M.$src.scroll = e, u()
                    },
                    duration: A,
                    easing: _
                }) : l(), d()
            }

            function u() {
                h(), void 0 !== customEventEngine && customEventEngine.call(D, "scrollChange", M.$src.scroll)
            }

            function h() {
                C == S.CSS3_EASED || C == S.NONE ? hotdot.applyHorizontalShift(-M.$src.scroll, M.$src, I) : C == S.JQ_EASED && g(M.$src, -M.$src.scroll);
                for (var e = 0, t = M.array[0], i = M.array.length; i > e; e++, t = M.array[e]) t.adjust()
            }

            function f() {
                var t = k.$src ? !1 : !0;
                if (t ? startWindowWidth = z : k.$src.remove(), e.touchNotScrollMode) {
                    var i = $("<div/>").css({
                        position: "absolute",
                        display: "hidden"
                    });
                    t && $("body").append(i), k.$src = $("<div/>").css({
                        width: M.width
                    });
                    var r = 0;
                    time = {
                        start: 0,
                        end: 0
                    };
                    var n, s = {
                        cur: 0,
                        max: 15,
                        min: .1
                    };
                    t && (M.$src[0].addEventListener("touchmove", function(e) {
                        if (!(e.touches.length > 1)) {
                            e.preventDefault(), time.end = (new Date).getTime(); {
                                time.end - time.start
                            }
                            n = e.touches[0].screenX - r, s.cur = n * n / 15 * (0 > n ? -1 : 1), k.add(-s.cur), r = e.touches[0].screenX, time.start = time.end
                        }
                    }), M.$src[0].addEventListener("touchstart", function(e) {
                        time.start = (new Date).getTime(), r = e.touches[0].screenX, k.stop()
                    }));
                    var o = M.width - z,
                        a = 0;
                    k.add = function(e) {
                        k.cur + e > o ? k.cur = o : k.cur + e < a ? k.cur = a : k.cur += e, c()
                    }, k.stop = function() {
                        k.cur = M.$src.scroll
                    }, k.get = function() {
                        return k.cur
                    }
                } else {
                    var l;
                    y || (k.$src = $("<div/>").css({
                        width: M.width,
                        height: "1px"
                    }), $("body").append(k.$src), l = window), k.get = function() {
                        return y ? k.cur : $(l).scrollLeft()
                    }, k.add = function(e) {
                        if (y) {
                            var t = k.cur + e;
                            return 0 > t ? t = 0 : t > k.maxLimit && (t = k.maxLimit), k.cur = t, void c()
                        }
                        $(l).scrollLeft($(l).scrollLeft() + e)
                    }, t && !y && $(l).on("scroll", c)
                }
                D.add = k.add, D.width = M.width
            }

            function p(e) {
                var t = k.get(),
                    i = e ? Math.floor : Math.ceil,
                    r = (t / M.singleSlideWidth, i(t / M.singleSlideWidth));
                t % M.singleSlideWidth == 0 && (r += e ? -1 : 1), r *= M.singleSlideWidth, D.to(r)
            }

            function v(e, t) {
                var i = A + "ms ease-in-out 1ms";
                e == E.LEFT ? transi = "left " + i : (e == E.TRANSLATE || e == E.TRANSLATEX || e == E.TRANSLATE3D) && (transi = "-webkit-transform " + i), t.css({
                    WebkitTransition: transi,
                    MozTransition: transi,
                    OTransition: transi,
                    msTransition: transi,
                    transition: transi
                })
            }

            function g(e, t) {
                e.stop(!1).animate({
                    left: t + "px"
                }, A, _)
            }
            var m = "parallax",
                w = "overflowsSlide",
                b = "parallaxBackground",
                y = e.removeScrollbar,
                S = {
                    NONE: 0,
                    JQ_EASED: 1,
                    CSS3_EASED: 2,
                    SUPER_EASED: 3,
                    EASED: 4
                },
                E = {
                    LEFT: "left",
                    TRANSLATEX: "translateX",
                    TRANSLATE: "translate",
                    TRANSLATE3D: "translate3d"
                },
                L = S.NONE,
                x = S.EASED,
                C = S.NONE,
                T = e.layerShiftProperty || "left",
                I = e.parallaxShiftProperty || "left",
                _ = "easeOutExpo",
                A = 1500;
            this.onInit = function() {};
            var z, D = this,
                M = {
                    $src: void 0,
                    array: [],
                    singleSlideWidth: 0
                },
                k = {
                    add: function() {},
                    get: function() {},
                    delta: 0,
                    cur: 0,
                    previous: 0,
                    maxLimit: 0,
                    firstStep: 0,
                    $src: void 0,
                    startWindowWidth: 0,
                    resizeModifier: 1,
                    minimalStep: 0
                };
            D.scroll = k, this.currentSlideI = 0, this.mouseWheelTarget = $("body"), this.stopParallax = !1, this.findLayerWrapper = function(e) {
                for (var t = 0, i = M.array[0]; t < M.array.length; t++, i = M.array[t])
                    for (var r = 0, n = i.layers[0]; r < i.layers.length; r++, n = i.layers[r])
                        if (e == n.$src[0]) return n
            };
            var N = "onBorder";
            this.init = r;
            var j, P, W = !1,
                R = 0,
                F = 0;
            this.toSlide = function(e) {
                e > -1 && e < M.array.length && this.to(z * e)
            }, this.to = function(e) {
                k.add(e - k.get())
            }, this.closerLeft = function() {
                p(!0)
            }, this.closerRight = function() {
                p(!1)
            };
            var H, O;
            this.onResizeSlides = function() {
                H = k.get(), O = H / z, s()
            }, this.onResizeLayers = function() {
                o(), u();
                var e = O * z;
                W = !0, k.add(e - k.get())
            }
        }
    }, {}],
    3: [function() {
        window.resizeables = {
            engineCreator: void 0,
            engine: void 0,
            initFromDescript: function(e) {
                resizeables.engine.getContainersFromDescript(e)
            },
            init: function() {
                resizeables.engine.findContainers()
            },
            adjust: function() {
                resizeables.engine.adjust()
            },
            fillModes: {
                FILL_PARENT: "fillParent",
                FIT_PARENT: "fitParent",
                FIT_PARENT_WIDTH: "fitParentWidth"
            },
            orientations: {
                LANDSCAPE: "landscape",
                PORTRAIT: "portrait"
            },
            criticalReadabilityClass: "criticalReadability",
            minimalReadableFontSize: 11,
            baseFontSize: 14
        }, resizeables.reference = {
            w: 1280,
            h: 923
        }, resizeables.engineCreator = function() {
            function e(e, i) {
                return new t({
                    $src: e,
                    fitting: i
                })
            }

            function t(e) {
                function t() {
                    u = windowAspect > f ? n.orientations.LANDSCAPE : n.orientations.PORTRAIT
                }
                var i, r, s, o, a, l = e.$src,
                    d = e.fitting,
                    c = e.multiLayout;
                this.recollectMetrics = function() {
                    l.css({
                        width: "",
                        height: "",
                        "font-size": ""
                    }), i = {
                        w: l.outerWidth(!0),
                        h: l.outerHeight(!0)
                    }, s = i.w / i.h, r = {
                        w: i.w / resizeables.reference.w,
                        h: i.h / resizeables.reference.h
                    }, o = parseInt(l.css("font-size"), 10)
                }, a = e.versionB, a && l.css("display", "inline-block"), this.recollectMetrics(), criticalElements = l.find("." + n.criticalReadabilityClass), this.parent = l.parent();
                var u, h = "none",
                    f = 1;
                e.layoutSwitchThreshold && (f = e.layoutSwitchThreshold), this.adjust = function() {
                    var e = $(window).innerWidth(),
                        f = $(window).innerHeight(),
                        p = e / f;
                    c && (t(), u != h && (l.addClass(u).removeClass(h), this.recollectMetrics(), h = u));
                    var v = "w",
                        g = "h";
                    d === n.fillModes.FILL_PARENT ? s > p && (v = "h") : d === n.fillModes.FIT_PARENT && p > s && (v = "h"), "h" == v && (g = "w");
                    var m, w = {
                            h: 0,
                            w: 0
                        },
                        b = {
                            h: f,
                            w: e
                        },
                        y = {
                            h: "margin-left",
                            w: "margin-top"
                        };
                    if (w[v] = b[v] * (d === n.fillModes.FILL_PARENT || a ? 1 : r[v]), w[g] = w[v], "h" == g ? w[g] /= s : w[g] *= s, w[g] > b[g]) {
                        var S = -(w[g] - b[g]) / 2,
                            E = y[v],
                            L = y[g];
                        l.css(L, ""), l.css(E, S)
                    }
                    m = w.h / i.h, l.width(w.w), l.height(w.h), m *= o, l.css("font-size", m);
                    for (var x = 0, C = criticalElements.length; C > x; x++) {
                        $ce = $(criticalElements[x]), $ce.css("font-size", "");
                        var T = parseInt($ce.css("font-size"), 10);
                        T < n.minimalReadableFontSize && $ce.css("font-size", n.minimalReadableFontSize + "px")
                    }
                }
            }
            var i, r = [],
                n = resizeables;
            return this.findContainers = function() {
                for (var t in n.fillModes) $("." + n.fillModes[t]).each(function() {
                    var i = new e($(this), n.fillModes[t]);
                    r.push(i)
                });
                i = r.length
            }, this.getContainersFromDescript = function(e) {
                for (var n in e) {
                    var s = e[n];
                    s.$src = $(s.srcString);
                    var o = new t(s);
                    r.push(o)
                }
                i = r.length
            }, this.adjust = function() {
                for (var e = 0, t = r[e]; i > e; e++, t = r[e]) t.adjust()
            }, this
        }, resizeables.engine = new resizeables.engineCreator, window.adjustFontSize = function() {
            var e = {
                    w: window.innerWidth / resizeables.reference.w,
                    h: window.innerHeight / resizeables.reference.h
                },
                t = void 0 !== resizeables && void 0 !== resizeables.baseFontSize ? resizeables.baseFontSize : 16;
            $("body").css("font-size", Math.min(8.4, t * Math.min(e.w, e.h)) + "px")
        }
    }, {}],
    4: [function() {
        jQuery.effects || function(e, t) {
            var i = e.uiBackCompat !== !1,
                r = "ui-effects-";
            e.effects = {
                    effect: {}
                },
                /*!
                 * jQuery Color Animations v2.0.0
                 * http://jquery.com/
                 *
                 * Copyright 2012 jQuery Foundation and other contributors
                 * Released under the MIT license.
                 * http://jquery.org/license
                 *
                 * Date: Mon Aug 13 13:41:02 2012 -0500
                 */
                function(t, i) {
                    function r(e, t, i) {
                        var r = h[t.type] || {};
                        return null == e ? i || !t.def ? null : t.def : (e = r.floor ? ~~e : parseFloat(e), isNaN(e) ? t.def : r.mod ? (e + r.mod) % r.mod : 0 > e ? 0 : r.max < e ? r.max : e)
                    }

                    function n(e) {
                        var i = c(),
                            r = i._rgba = [];
                        return e = e.toLowerCase(), v(d, function(t, n) {
                            var s, o = n.re.exec(e),
                                a = o && n.parse(o),
                                l = n.space || "rgba";
                            return a ? (s = i[l](a), i[u[l].cache] = s[u[l].cache], r = i._rgba = s._rgba, !1) : void 0
                        }), r.length ? ("0,0,0,0" === r.join() && t.extend(r, o.transparent), i) : o[e]
                    }

                    function s(e, t, i) {
                        return i = (i + 1) % 1, 1 > 6 * i ? e + (t - e) * i * 6 : 1 > 2 * i ? t : 2 > 3 * i ? e + (t - e) * (2 / 3 - i) * 6 : e
                    }
                    var o, a = "backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor".split(" "),
                        l = /^([\-+])=\s*(\d+\.?\d*)/,
                        d = [{
                            re: /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/,
                            parse: function(e) {
                                return [e[1], e[2], e[3], e[4]]
                            }
                        }, {
                            re: /rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/,
                            parse: function(e) {
                                return [2.55 * e[1], 2.55 * e[2], 2.55 * e[3], e[4]]
                            }
                        }, {
                            re: /#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})/,
                            parse: function(e) {
                                return [parseInt(e[1], 16), parseInt(e[2], 16), parseInt(e[3], 16)]
                            }
                        }, {
                            re: /#([a-f0-9])([a-f0-9])([a-f0-9])/,
                            parse: function(e) {
                                return [parseInt(e[1] + e[1], 16), parseInt(e[2] + e[2], 16), parseInt(e[3] + e[3], 16)]
                            }
                        }, {
                            re: /hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d+(?:\.\d+)?)\s*)?\)/,
                            space: "hsla",
                            parse: function(e) {
                                return [e[1], e[2] / 100, e[3] / 100, e[4]]
                            }
                        }],
                        c = t.Color = function(e, i, r, n) {
                            return new t.Color.fn.parse(e, i, r, n)
                        },
                        u = {
                            rgba: {
                                props: {
                                    red: {
                                        idx: 0,
                                        type: "byte"
                                    },
                                    green: {
                                        idx: 1,
                                        type: "byte"
                                    },
                                    blue: {
                                        idx: 2,
                                        type: "byte"
                                    }
                                }
                            },
                            hsla: {
                                props: {
                                    hue: {
                                        idx: 0,
                                        type: "degrees"
                                    },
                                    saturation: {
                                        idx: 1,
                                        type: "percent"
                                    },
                                    lightness: {
                                        idx: 2,
                                        type: "percent"
                                    }
                                }
                            }
                        },
                        h = {
                            "byte": {
                                floor: !0,
                                max: 255
                            },
                            percent: {
                                max: 1
                            },
                            degrees: {
                                mod: 360,
                                floor: !0
                            }
                        },
                        f = c.support = {},
                        p = t("<p>")[0],
                        v = t.each;
                    p.style.cssText = "background-color:rgba(1,1,1,.5)", f.rgba = p.style.backgroundColor.indexOf("rgba") > -1, v(u, function(e, t) {
                        t.cache = "_" + e, t.props.alpha = {
                            idx: 3,
                            type: "percent",
                            def: 1
                        }
                    }), c.fn = t.extend(c.prototype, {
                        parse: function(s, a, l, d) {
                            if (s === i) return this._rgba = [null, null, null, null], this;
                            (s.jquery || s.nodeType) && (s = t(s).css(a), a = i);
                            var h = this,
                                f = t.type(s),
                                p = this._rgba = [];
                            return a !== i && (s = [s, a, l, d], f = "array"), "string" === f ? this.parse(n(s) || o._default) : "array" === f ? (v(u.rgba.props, function(e, t) {
                                p[t.idx] = r(s[t.idx], t)
                            }), this) : "object" === f ? (s instanceof c ? v(u, function(e, t) {
                                s[t.cache] && (h[t.cache] = s[t.cache].slice())
                            }) : v(u, function(t, i) {
                                var n = i.cache;
                                v(i.props, function(e, t) {
                                    if (!h[n] && i.to) {
                                        if ("alpha" === e || null == s[e]) return;
                                        h[n] = i.to(h._rgba)
                                    }
                                    h[n][t.idx] = r(s[e], t, !0)
                                }), h[n] && e.inArray(null, h[n].slice(0, 3)) < 0 && (h[n][3] = 1, i.from && (h._rgba = i.from(h[n])))
                            }), this) : void 0
                        },
                        is: function(e) {
                            var t = c(e),
                                i = !0,
                                r = this;
                            return v(u, function(e, n) {
                                var s, o = t[n.cache];
                                return o && (s = r[n.cache] || n.to && n.to(r._rgba) || [], v(n.props, function(e, t) {
                                    return null != o[t.idx] ? i = o[t.idx] === s[t.idx] : void 0
                                })), i
                            }), i
                        },
                        _space: function() {
                            var e = [],
                                t = this;
                            return v(u, function(i, r) {
                                t[r.cache] && e.push(i)
                            }), e.pop()
                        },
                        transition: function(e, t) {
                            var i = c(e),
                                n = i._space(),
                                s = u[n],
                                o = 0 === this.alpha() ? c("transparent") : this,
                                a = o[s.cache] || s.to(o._rgba),
                                l = a.slice();
                            return i = i[s.cache], v(s.props, function(e, n) {
                                var s = n.idx,
                                    o = a[s],
                                    d = i[s],
                                    c = h[n.type] || {};
                                null !== d && (null === o ? l[s] = d : (c.mod && (d - o > c.mod / 2 ? o += c.mod : o - d > c.mod / 2 && (o -= c.mod)), l[s] = r((d - o) * t + o, n)))
                            }), this[n](l)
                        },
                        blend: function(e) {
                            if (1 === this._rgba[3]) return this;
                            var i = this._rgba.slice(),
                                r = i.pop(),
                                n = c(e)._rgba;
                            return c(t.map(i, function(e, t) {
                                return (1 - r) * n[t] + r * e
                            }))
                        },
                        toRgbaString: function() {
                            var e = "rgba(",
                                i = t.map(this._rgba, function(e, t) {
                                    return null == e ? t > 2 ? 1 : 0 : e
                                });
                            return 1 === i[3] && (i.pop(), e = "rgb("), e + i.join() + ")"
                        },
                        toHslaString: function() {
                            var e = "hsla(",
                                i = t.map(this.hsla(), function(e, t) {
                                    return null == e && (e = t > 2 ? 1 : 0), t && 3 > t && (e = Math.round(100 * e) + "%"), e
                                });
                            return 1 === i[3] && (i.pop(), e = "hsl("), e + i.join() + ")"
                        },
                        toHexString: function(e) {
                            var i = this._rgba.slice(),
                                r = i.pop();
                            return e && i.push(~~(255 * r)), "#" + t.map(i, function(e) {
                                return e = (e || 0).toString(16), 1 === e.length ? "0" + e : e
                            }).join("")
                        },
                        toString: function() {
                            return 0 === this._rgba[3] ? "transparent" : this.toRgbaString()
                        }
                    }), c.fn.parse.prototype = c.fn, u.hsla.to = function(e) {
                        if (null == e[0] || null == e[1] || null == e[2]) return [null, null, null, e[3]];
                        var t, i, r = e[0] / 255,
                            n = e[1] / 255,
                            s = e[2] / 255,
                            o = e[3],
                            a = Math.max(r, n, s),
                            l = Math.min(r, n, s),
                            d = a - l,
                            c = a + l,
                            u = .5 * c;
                        return t = l === a ? 0 : r === a ? 60 * (n - s) / d + 360 : n === a ? 60 * (s - r) / d + 120 : 60 * (r - n) / d + 240, i = 0 === u || 1 === u ? u : .5 >= u ? d / c : d / (2 - c), [Math.round(t) % 360, i, u, null == o ? 1 : o]
                    }, u.hsla.from = function(e) {
                        if (null == e[0] || null == e[1] || null == e[2]) return [null, null, null, e[3]];
                        var t = e[0] / 360,
                            i = e[1],
                            r = e[2],
                            n = e[3],
                            o = .5 >= r ? r * (1 + i) : r + i - r * i,
                            a = 2 * r - o;
                        return [Math.round(255 * s(a, o, t + 1 / 3)), Math.round(255 * s(a, o, t)), Math.round(255 * s(a, o, t - 1 / 3)), n]
                    }, v(u, function(e, n) {
                        var s = n.props,
                            o = n.cache,
                            a = n.to,
                            d = n.from;
                        c.fn[e] = function(e) {
                            if (a && !this[o] && (this[o] = a(this._rgba)), e === i) return this[o].slice();
                            var n, l = t.type(e),
                                u = "array" === l || "object" === l ? e : arguments,
                                h = this[o].slice();
                            return v(s, function(e, t) {
                                var i = u["object" === l ? e : t.idx];
                                null == i && (i = h[t.idx]), h[t.idx] = r(i, t)
                            }), d ? (n = c(d(h)), n[o] = h, n) : c(h)
                        }, v(s, function(i, r) {
                            c.fn[i] || (c.fn[i] = function(n) {
                                var s, o = t.type(n),
                                    a = "alpha" === i ? this._hsla ? "hsla" : "rgba" : e,
                                    d = this[a](),
                                    c = d[r.idx];
                                return "undefined" === o ? c : ("function" === o && (n = n.call(this, c), o = t.type(n)), null == n && r.empty ? this : ("string" === o && (s = l.exec(n), s && (n = c + parseFloat(s[2]) * ("+" === s[1] ? 1 : -1))), d[r.idx] = n, this[a](d)))
                            })
                        })
                    }), v(a, function(e, i) {
                        t.cssHooks[i] = {
                            set: function(e, r) {
                                var s, o, a = "";
                                if ("string" !== t.type(r) || (s = n(r))) {
                                    if (r = c(s || r), !f.rgba && 1 !== r._rgba[3]) {
                                        for (o = "backgroundColor" === i ? e.parentNode : e;
                                            ("" === a || "transparent" === a) && o && o.style;) try {
                                            a = t.css(o, "backgroundColor"), o = o.parentNode
                                        } catch (l) {}
                                        r = r.blend(a && "transparent" !== a ? a : "_default")
                                    }
                                    r = r.toRgbaString()
                                }
                                try {
                                    e.style[i] = r
                                } catch (d) {}
                            }
                        }, t.fx.step[i] = function(e) {
                            e.colorInit || (e.start = c(e.elem, i), e.end = c(e.end), e.colorInit = !0), t.cssHooks[i].set(e.elem, e.start.transition(e.end, e.pos))
                        }
                    }), t.cssHooks.borderColor = {
                        expand: function(e) {
                            var t = {};
                            return v(["Top", "Right", "Bottom", "Left"], function(i, r) {
                                t["border" + r + "Color"] = e
                            }), t
                        }
                    }, o = t.Color.names = {
                        aqua: "#00ffff",
                        black: "#000000",
                        blue: "#0000ff",
                        fuchsia: "#ff00ff",
                        gray: "#808080",
                        green: "#008000",
                        lime: "#00ff00",
                        maroon: "#800000",
                        navy: "#000080",
                        olive: "#808000",
                        purple: "#800080",
                        red: "#ff0000",
                        silver: "#c0c0c0",
                        teal: "#008080",
                        white: "#ffffff",
                        yellow: "#ffff00",
                        transparent: [null, null, null, 0],
                        _default: "#ffffff"
                    }
                }(jQuery),
                function() {
                    function i() {
                        var t, i, r = this.ownerDocument.defaultView ? this.ownerDocument.defaultView.getComputedStyle(this, null) : this.currentStyle,
                            n = {};
                        if (r && r.length && r[0] && r[r[0]])
                            for (i = r.length; i--;) t = r[i], "string" == typeof r[t] && (n[e.camelCase(t)] = r[t]);
                        else
                            for (t in r) "string" == typeof r[t] && (n[t] = r[t]);
                        return n
                    }

                    function r(t, i) {
                        var r, n, o = {};
                        for (r in i) n = i[r], t[r] !== n && (s[r] || (e.fx.step[r] || !isNaN(parseFloat(n))) && (o[r] = n));
                        return o
                    }
                    var n = ["add", "remove", "toggle"],
                        s = {
                            border: 1,
                            borderBottom: 1,
                            borderColor: 1,
                            borderLeft: 1,
                            borderRight: 1,
                            borderTop: 1,
                            borderWidth: 1,
                            margin: 1,
                            padding: 1
                        };
                    e.each(["borderLeftStyle", "borderRightStyle", "borderBottomStyle", "borderTopStyle"], function(t, i) {
                        e.fx.step[i] = function(e) {
                            ("none" !== e.end && !e.setAttr || 1 === e.pos && !e.setAttr) && (jQuery.style(e.elem, i, e.end), e.setAttr = !0)
                        }
                    }), e.effects.animateClass = function(t, s, o, a) {
                        var l = e.speed(s, o, a);
                        return this.queue(function() {
                            var s, o = e(this),
                                a = o.attr("class") || "",
                                d = l.children ? o.find("*").andSelf() : o;
                            d = d.map(function() {
                                var t = e(this);
                                return {
                                    el: t,
                                    start: i.call(this)
                                }
                            }), s = function() {
                                e.each(n, function(e, i) {
                                    t[i] && o[i + "Class"](t[i])
                                })
                            }, s(), d = d.map(function() {
                                return this.end = i.call(this.el[0]), this.diff = r(this.start, this.end), this
                            }), o.attr("class", a), d = d.map(function() {
                                var t = this,
                                    i = e.Deferred(),
                                    r = jQuery.extend({}, l, {
                                        queue: !1,
                                        complete: function() {
                                            i.resolve(t)
                                        }
                                    });
                                return this.el.animate(this.diff, r), i.promise()
                            }), e.when.apply(e, d.get()).done(function() {
                                s(), e.each(arguments, function() {
                                    var t = this.el;
                                    e.each(this.diff, function(e) {
                                        t.css(e, "")
                                    })
                                }), l.complete.call(o[0])
                            })
                        })
                    }, e.fn.extend({
                        _addClass: e.fn.addClass,
                        addClass: function(t, i, r, n) {
                            return i ? e.effects.animateClass.call(this, {
                                add: t
                            }, i, r, n) : this._addClass(t)
                        },
                        _removeClass: e.fn.removeClass,
                        removeClass: function(t, i, r, n) {
                            return i ? e.effects.animateClass.call(this, {
                                remove: t
                            }, i, r, n) : this._removeClass(t)
                        },
                        _toggleClass: e.fn.toggleClass,
                        toggleClass: function(i, r, n, s, o) {
                            return "boolean" == typeof r || r === t ? n ? e.effects.animateClass.call(this, r ? {
                                add: i
                            } : {
                                remove: i
                            }, n, s, o) : this._toggleClass(i, r) : e.effects.animateClass.call(this, {
                                toggle: i
                            }, r, n, s)
                        },
                        switchClass: function(t, i, r, n, s) {
                            return e.effects.animateClass.call(this, {
                                add: i,
                                remove: t
                            }, r, n, s)
                        }
                    })
                }(),
                function() {
                    function n(t, i, r, n) {
                        return e.isPlainObject(t) && (i = t, t = t.effect), t = {
                            effect: t
                        }, null == i && (i = {}), e.isFunction(i) && (n = i, r = null, i = {}), ("number" == typeof i || e.fx.speeds[i]) && (n = r, r = i, i = {}), e.isFunction(r) && (n = r, r = null), i && e.extend(t, i), r = r || i.duration, t.duration = e.fx.off ? 0 : "number" == typeof r ? r : r in e.fx.speeds ? e.fx.speeds[r] : e.fx.speeds._default, t.complete = n || i.complete, t
                    }

                    function s(t) {
                        return !t || "number" == typeof t || e.fx.speeds[t] ? !0 : "string" != typeof t || e.effects.effect[t] ? !1 : i && e.effects[t] ? !1 : !0
                    }
                    e.extend(e.effects, {
                        version: "1.9.1",
                        save: function(e, t) {
                            for (var i = 0; i < t.length; i++) null !== t[i] && e.data(r + t[i], e[0].style[t[i]])
                        },
                        restore: function(e, i) {
                            var n, s;
                            for (s = 0; s < i.length; s++) null !== i[s] && (n = e.data(r + i[s]), n === t && (n = ""), e.css(i[s], n))
                        },
                        setMode: function(e, t) {
                            return "toggle" === t && (t = e.is(":hidden") ? "show" : "hide"), t
                        },
                        getBaseline: function(e, t) {
                            var i, r;
                            switch (e[0]) {
                                case "top":
                                    i = 0;
                                    break;
                                case "middle":
                                    i = .5;
                                    break;
                                case "bottom":
                                    i = 1;
                                    break;
                                default:
                                    i = e[0] / t.height
                            }
                            switch (e[1]) {
                                case "left":
                                    r = 0;
                                    break;
                                case "center":
                                    r = .5;
                                    break;
                                case "right":
                                    r = 1;
                                    break;
                                default:
                                    r = e[1] / t.width
                            }
                            return {
                                x: r,
                                y: i
                            }
                        },
                        createWrapper: function(t) {
                            if (t.parent().is(".ui-effects-wrapper")) return t.parent();
                            var i = {
                                    width: t.outerWidth(!0),
                                    height: t.outerHeight(!0),
                                    "float": t.css("float")
                                },
                                r = e("<div></div>").addClass("ui-effects-wrapper").css({
                                    fontSize: "100%",
                                    background: "transparent",
                                    border: "none",
                                    margin: 0,
                                    padding: 0
                                }),
                                n = {
                                    width: t.width(),
                                    height: t.height()
                                },
                                s = document.activeElement;
                            try {
                                s.id
                            } catch (o) {
                                s = document.body
                            }
                            return t.wrap(r), (t[0] === s || e.contains(t[0], s)) && e(s).focus(), r = t.parent(), "static" === t.css("position") ? (r.css({
                                position: "relative"
                            }), t.css({
                                position: "relative"
                            })) : (e.extend(i, {
                                position: t.css("position"),
                                zIndex: t.css("z-index")
                            }), e.each(["top", "left", "bottom", "right"], function(e, r) {
                                i[r] = t.css(r), isNaN(parseInt(i[r], 10)) && (i[r] = "auto")
                            }), t.css({
                                position: "relative",
                                top: 0,
                                left: 0,
                                right: "auto",
                                bottom: "auto"
                            })), t.css(n), r.css(i).show()
                        },
                        removeWrapper: function(t) {
                            var i = document.activeElement;
                            return t.parent().is(".ui-effects-wrapper") && (t.parent().replaceWith(t), (t[0] === i || e.contains(t[0], i)) && e(i).focus()), t
                        },
                        setTransition: function(t, i, r, n) {
                            return n = n || {}, e.each(i, function(e, i) {
                                var s = t.cssUnit(i);
                                s[0] > 0 && (n[i] = s[0] * r + s[1])
                            }), n
                        }
                    }), e.fn.extend({
                        effect: function() {
                            function t(t) {
                                function i() {
                                    e.isFunction(s) && s.call(n[0]), e.isFunction(t) && t()
                                }
                                var n = e(this),
                                    s = r.complete,
                                    o = r.mode;
                                (n.is(":hidden") ? "hide" === o : "show" === o) ? i(): a.call(n[0], r, i)
                            }
                            var r = n.apply(this, arguments),
                                s = r.mode,
                                o = r.queue,
                                a = e.effects.effect[r.effect],
                                l = !a && i && e.effects[r.effect];
                            return e.fx.off || !a && !l ? s ? this[s](r.duration, r.complete) : this.each(function() {
                                r.complete && r.complete.call(this)
                            }) : a ? o === !1 ? this.each(t) : this.queue(o || "fx", t) : l.call(this, {
                                options: r,
                                duration: r.duration,
                                callback: r.complete,
                                mode: r.mode
                            })
                        },
                        _show: e.fn.show,
                        show: function(e) {
                            if (s(e)) return this._show.apply(this, arguments);
                            var t = n.apply(this, arguments);
                            return t.mode = "show", this.effect.call(this, t)
                        },
                        _hide: e.fn.hide,
                        hide: function(e) {
                            if (s(e)) return this._hide.apply(this, arguments);
                            var t = n.apply(this, arguments);
                            return t.mode = "hide", this.effect.call(this, t)
                        },
                        __toggle: e.fn.toggle,
                        toggle: function(t) {
                            if (s(t) || "boolean" == typeof t || e.isFunction(t)) return this.__toggle.apply(this, arguments);
                            var i = n.apply(this, arguments);
                            return i.mode = "toggle", this.effect.call(this, i)
                        },
                        cssUnit: function(t) {
                            var i = this.css(t),
                                r = [];
                            return e.each(["em", "px", "%", "pt"], function(e, t) {
                                i.indexOf(t) > 0 && (r = [parseFloat(i), t])
                            }), r
                        }
                    })
                }(),
                function() {
                    var t = {};
                    e.each(["Quad", "Cubic", "Quart", "Quint", "Expo"], function(e, i) {
                        t[i] = function(t) {
                            return Math.pow(t, e + 2)
                        }
                    }), e.extend(t, {
                        Sine: function(e) {
                            return 1 - Math.cos(e * Math.PI / 2)
                        },
                        Circ: function(e) {
                            return 1 - Math.sqrt(1 - e * e)
                        },
                        Elastic: function(e) {
                            return 0 === e || 1 === e ? e : -Math.pow(2, 8 * (e - 1)) * Math.sin((80 * (e - 1) - 7.5) * Math.PI / 15)
                        },
                        Back: function(e) {
                            return e * e * (3 * e - 2)
                        },
                        Bounce: function(e) {
                            for (var t, i = 4; e < ((t = Math.pow(2, --i)) - 1) / 11;);
                            return 1 / Math.pow(4, 3 - i) - 7.5625 * Math.pow((3 * t - 2) / 22 - e, 2)
                        }
                    }), e.each(t, function(t, i) {
                        e.easing["easeIn" + t] = i, e.easing["easeOut" + t] = function(e) {
                            return 1 - i(1 - e)
                        }, e.easing["easeInOut" + t] = function(e) {
                            return .5 > e ? i(2 * e) / 2 : 1 - i(-2 * e + 2) / 2
                        }
                    })
                }()
        }(jQuery)
    }, {}],
    5: [function() {
        /*! Copyright (c) 2011 Brandon Aaron (http://brandonaaron.net)
         * Licensed under the MIT License (LICENSE.txt).
         *
         * Thanks to: http://adomas.org/javascript-mouse-wheel/ for some pointers.
         * Thanks to: Mathias Bank(http://www.mathias-bank.de) for a scope bug fix.
         * Thanks to: Seamus Leahy for adding deltaX and deltaY
         *
         * Version: 3.0.6
         * 
         * Requires: 1.2.2+
         */
        ! function(e) {
            function t(t) {
                var i = t || window.event,
                    r = [].slice.call(arguments, 1),
                    n = 0,
                    s = 0,
                    o = 0;
                return t = e.event.fix(i), t.type = "mousewheel", i.wheelDelta && (n = i.wheelDelta / 120), i.detail && (n = -i.detail / 3), o = n, void 0 !== i.axis && i.axis === i.HORIZONTAL_AXIS && (o = 0, s = -1 * n), void 0 !== i.wheelDeltaY && (o = i.wheelDeltaY / 120), void 0 !== i.wheelDeltaX && (s = -1 * i.wheelDeltaX / 120), r.unshift(t, n, s, o), (e.event.dispatch || e.event.handle).apply(this, r)
            }
            var i = ["DOMMouseScroll", "mousewheel"];
            if (e.event.fixHooks)
                for (var r = i.length; r;) e.event.fixHooks[i[--r]] = e.event.mouseHooks;
            e.event.special.mousewheel = {
                setup: function() {
                    if (this.addEventListener)
                        for (var e = i.length; e;) this.addEventListener(i[--e], t, !1);
                    else this.onmousewheel = t
                },
                teardown: function() {
                    if (this.removeEventListener)
                        for (var e = i.length; e;) this.removeEventListener(i[--e], t, !1);
                    else this.onmousewheel = null
                }
            }, e.fn.extend({
                mousewheel: function(e) {
                    return e ? this.bind("mousewheel", e) : this.trigger("mousewheel")
                },
                unmousewheel: function(e) {
                    return this.unbind("mousewheel", e)
                }
            })
        }(jQuery)
    }, {}],
    6: [function() {
        function e() {
            function e() {
                Modernizr.history && $("a").on("click", function() {
                    var e = $(this).attr("href");
                    "" != e && "#" != e && window.history.pushState({
                        mediaIsLoaded: "true"
                    }, "mediaIsLoaded")
                }), tdLib.debLog("in preloader.onLoad"), resizeables.initFromDescript(o), r(), parallax && para.init(), t(), $("#parallax").trigger("preloadFinish")
            }
            Modernizr.history && window.history.state && window.history.state.mediaIsLoaded && (tdLib.debLog("Already visted. No preloader"), hotdot.preloaderEnabled = !1), u = $("#intro"), a = $("#footer"), tdLib.debLog("mainPageInit"), debugging = self.location.toString().indexOf("xe") > -1;
            var n = {
                removeScrollbar: hotdot.settings.removeScrollbar,
                touchNotScrollMode: hotdot.settings.touchNotScrollMode
            };
            Modernizr.csstransforms3d && (n.layerShiftProperty = "translate3d", n.parallaxShiftProperty = "translate3d"), para = new parallax(n), tdLib.debLog("afterPara"), void 0 !== window.resizeables && (resizeables.baseFontSize = parseInt($("body").css("font-size"))), para.onInit = function() {
                tdLib.debLog("para.onInit"), para.mouseWheelTarget.bind("mousewheel", s), $(window).on("resize", i), preloader.disable(), f.applyHashFromAddressLine(), tdLib.debLog("no fix")
            }, customEventEngine.bind(para, "scrollChange", function() {
                f.trackHashChange()
            }), customEventEngine.bind(para, "startedMove", function() {
                !hotdot.settings.pauseSideAnimationsWhenMoving
            }), hotdot.preloaderEnabled ? preloader.onLoad = e : (preloader.init(), e(), setTimeout(function() {
                i()
            }, 300)), hotdot.preloaderEnabled && preloader.start(), tdLib.debLog("at the end of main routine")
        }

        function t() {
            var e = u.find(".intro-1stImg"),
                t = d / 2,
                i = e.width() / 2;
            if (e.css({
                    position: "absolute",
                    left: t - i
                }), c > 993) {
                var r = c / 2;
                u.find("img").each(function() {
                    var e = $(this);
                    e.css("bottom", r - 496.5)
                })
            } else u.find("img").each(function() {
                var e = $(this);
                e.css("bottom", "auto")
            })
        }

        function i() {
            para.onResizeSlides(), r(), para.onResizeLayers(), t()
        }

        function r() {
            d = $(window).innerWidth(), c = $(window).innerHeight(), l = d / c, h = n(d), adjustFontSize(), resizeables.adjust()
        }

        function n(e) {
            var t = hotdot.settings.mousewheelSlowness.windows;
            return tdLib.deviceDescription.os == tdLib.OS_TYPES.mac && (t = hotdot.settings.mousewheelSlowness.mac), e / t
        }

        function s(e, t) {
            return para.stopParallax ? !1 : (para.add(-t * h), e.preventDefault(), void e.stopPropagation())
        }
        var o = [{
            srcString: "video",
            fitting: resizeables.fillModes.FILL_PARENT
        }];
        window.para = {};
        var a, l, d, c, u, h;
        hotdot.animateOnlyHDLogo = !1, hotdot.preloaderEnabled = !0, hotdot.settings = {
            isWindowsSafari: tdLib.deviceDescription.type == tdLib.DEVICE_TYPES.desktop && tdLib.deviceDescription.os != tdLib.OS_TYPES.mac && tdLib.deviceDescription.browser == tdLib.BROWSERS.safari,
            disableAutoHashChange: tdLib.deviceDescription.type == tdLib.DEVICE_TYPES.android,
            removeScrollbar: tdLib.deviceDescription.type != tdLib.DEVICE_TYPES.wPhone,
            touchNotScrollMode: tdLib.deviceDescription.type != tdLib.DEVICE_TYPES.desktop && tdLib.deviceDescription.touchCapable,
            showTouchHint: tdLib.deviceDescription.type != tdLib.DEVICE_TYPES.desktop && (supportsTouchEvents || tdLib.deviceDescription.touchCapable),
            isAppleMobileDevice: tdLib.deviceDescription.type == tdLib.DEVICE_TYPES.iPad || tdLib.deviceDescription.type == tdLib.DEVICE_TYPES.iPhone,
            mousewheelSlowness: {
                windows: 15,
                mac: 60
            },
            pauseSideAnimationsWhenMoving: !0
        }, hotdot.settings.logoNavigationAdvancedRendering = Modernizr.csstransforms3d && !hotdot.settings.isWindowsSafari, document.ontouchmove = function(e) {
            e.preventDefault()
        }, $(document).keydown(function(e) {
            return "37" == e.keyCode || "39" == e.keyCode || "32" == e.keyCode ? para.stopParallax ? !1 : void("37" == e.keyCode ? (para.closerLeft(), e.preventDefault()) : ("39" == e.keyCode || "32" == e.keyCode) && (para.closerRight(), e.preventDefault())) : void 0
        });
        var f = {
            addrMap: ["", "bcode", "digitaltrip", "kynsi", "kis2015", "bilet2u"],
            doNotApplyHashFromAddressLine: !1,
            userLock: !1,
            lastSlideI: 0,
            applyHashFromAddressLine: function() {
                var e = self.location.toString(),
                    t = e.slice(e.indexOf("#") + 1);
                if (void 0 != t)
                    for (var i in f.addrMap)
                        if (t == f.addrMap[i] && i != f.lastSlideI) return f.userLock = !0, void para.toSlide(+i)
            },
            trackHashChange: function() {
                if (!hotdot.settings.disableAutoHashChange && para.currentSlideI != f.lastSlideI) {
                    if (f.lastSlideI = para.currentSlideI, f.userLock) return void(f.userLock = !1);
                    f.doNotApplyHashFromAddressLine = !0;
                    var e = "trackHashChange : Changing hash. ";
                    f.doNotApplyHashFromAddressLine && (e += " Has doNotApplyHashFromAddressLine."), f.userLock && (e += " Has userHashLock."), window.location.hash = f.addrMap[para.currentSlideI]
                }
            }
        };
        $(window).on("hashchange", function(e) {
            return e.preventDefault(), f.doNotApplyHashFromAddressLine ? void(f.doNotApplyHashFromAddressLine = !1) : (f.applyHashFromAddressLine(), !1)
        }), $(e)
    }, {}],
    7: [function() {
        window.onload = function() {
            function e() {
                try {
                    return document.createEvent("TouchEvent"), !0
                } catch (e) {
                    return !1
                }
            }

            function t(e) {
                var t = window.location.href,
                    n = t.substring(t.lastIndexOf("#"));
                i = setTimeout(function() {
                    para.currentSlideI == para.slidesCount - 0.1 ? $(".left-arrow").fadeIn(0.1) : 0 == para.currentSlideI ? ($(".right-arrow").fadeIn(), r && ("#" == n || n) && $(".nav-animation").fadeIn(0.1)) : $(".left-arrow, .right-arrow").fadeIn(0.1), r = !1
                }, e)
            }
            var i, r = !0;
            setTimeout(function() {
                customEventEngine.bind(para, "finishedMove", function() {
                    t(0.1)
                }), customEventEngine.bind(para, "startedMove", function() {
                    clearTimeout(i), $(".left-arrow, .right-arrow, .nav-animation").css("display", "none")
                }), t(0.1), $(".left-arrow").click(para.closerLeft), $(".right-arrow").click(para.closerRight)
            }, 0.1), $(".left-arrow, .right-arrow, .nav-animation").addClass(e() ? "touch" : "no-touch")
        }
    }, {}],
    8: [function() {
        window.preloader = {
            disable: void 0,
            start: void 0,
            onLoad: function() {},
            $slide: void 0,
            visuals: void 0,
            fillVisuals: function() {},
             fillingTime: 0,
            fillingTime: 0,
            delayBeforeLoadCheck: 0,
            targetLogoWidth: 0
        };
        var e = "loadBackground";
        preloader.fillVisuals = function(e, t) {
            t || (t = function() {}), preloader.visuals.loaded.animate({
                width: preloader.targetLogoWidth * e
            }, {
                duration: preloader.fillingTime,
                queue: !1
            }), preloader.visuals.unloaded.animate({
                width: (1 - e) * preloader.targetLogoWidth
            }, {
                duration: preloader.fillingTime,
                queue: !1,
                complete: t
            })
        }, preloader.disable = function(t) {
            t && t.rough ? ($("." + e).remove(), preloader.$slide.remove()) : ($("." + e).delay(0).animate({
                opacity: 0
            }, preloader.fillingTime, function() {
                $(this).remove()
            }), preloader.$slide.animate({
                opacity: 0
            }, preloader.fillingTime, function() {
                $(this).remove()
            })), $(document.body).removeClass("unloaded")
        }, preloader.init = function() {
            preloader.visuals = {
                loaded: $(".Preload-end"),
                unloaded: $(".Preload-start")
            }, preloader.$slide = $(".Preloader"), preloader.targetLogoWidth = .1 * $(window).innerWidth()
        }, preloader.start = function() {
            function e() {
                var e = r.filter(function() {
                    return this.src && this.src.indexOf("svg") > -1 ? !1 : void 0 !== this.readyState && this.readyState >= 1 ? !1 : this.complete ? !1 : !0
                });
                return e.length
            }

            function t() {
                var t = e();
                return 0 == t ? (tdLib.debLog("No need to load."), preloader.onLoad(), void preloader.disable({
                    rough: !1
                })) : (preloader.visuals.loaded.add(preloader.visuals.unloaded).animate({
                    opacity: 1
                }, 3), void i())
            }

            function i() {
                var t = e(),
                    r = (n - t) / n;
                0 == t ? (tdLib.debLog("Finished loading"), preloader.fillVisuals(r, preloader.onLoad)) : (setTimeout(i, .0), tdLib.debLog("Still need to load " + t), preloader.fillVisuals(r))
            }
            preloader.init(); {
                var r = $("html").find("img,video"),
                    n = r.length;
                this.onContentLoad
            }
            preloader.visuals.loaded.add(preloader.visuals.unloaded).css("opacity", 0);
            var s = $(".Preloader .subCont"),
                o = preloader.visuals.loaded.find("img").width() / preloader.visuals.loaded.find("img").height();
            preloader.visuals.loaded.find("img").add(preloader.visuals.unloaded.find("img")).add(preloader.visuals.unloaded).css("width", preloader.targetLogoWidth), s.add(preloader.visuals.loaded.find("img")).add(preloader.visuals.unloaded.find("img")).css("height", preloader.targetLogoWidth / o), setTimeout(t, preloader.delayBeforeLoadCheck)
        }
    }, {}],
    9: [function() {
        ! function(e) {
            e.customEventEngine = {
                init: function(e, t) {
                    e.cUE || (e.cUE = {}), e.cUE[t] || (e.cUE[t] = [])
                },
                call: function(t, i, r) {
                    t.cUE && t.cUE[i] || e.customEventEngine.init(t, i);
                    for (var n in t.cUE[i]) t.cUE[i][n](r)
                },
                bind: function(t, i, r) {
                    t.cUE && t.cUE[i] || e.customEventEngine.init(t, i), t.cUE[i].push(r)
                }
            }
        }(window)
    }, {}]
}, {}, [1]);



console.dir(e);

